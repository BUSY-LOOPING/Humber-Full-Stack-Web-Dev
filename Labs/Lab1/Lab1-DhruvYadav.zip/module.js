let array = ['apples', 'bananas', 'cherries', 'oranges', 'pears'];

export function addToArray(item) {
  array.push(item);
}

export function getArrayLength() {
    return array.length;
}