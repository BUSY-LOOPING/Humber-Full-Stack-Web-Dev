//import required modules
import express, { response } from "express"; //const express require("express"); olded es5 syntax
//must use type:module is package.json 
import path from "path";
import { MongoClient, ObjectId } from "mongodb";
import { request } from "http";

//in the older ES5, there is a special vairable called __dirname to retrieve the absolute path of the current folder. this doesnot exist in ES6 version for node.js

const __dirname = import.meta.dirname;

const dbUrl = 'mongodb://localhost:27017/';
const db = new MongoClient(dbUrl).db('testdb');

const app = express(); //create an express application
const port = process.env.PORT || "8888";


//setup express app to make POST request data available through request.body
app.use(express.urlencoded({extended: true})); //for parsing application/x-www-form-urlencoded
app.use(express.json()); //for parsing application/json

//set up expres  app to set the "Views" setting (first argument) to use the views folder for the template files
console.log("path = " +  path.join(__dirname, "views"));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug"); //should be the package name for the template engine

app.use(express.static(path.join(__dirname, "public")));

app.get("/", async (request, response) => {
    let linkList = await getLinks();
    response.render("index", {title: "Home", links: linkList});
});

app.get("/about", (request, response) => {
    response.render("about", {title: "About"});
});

//MENU LINK ADMIN
app.get("/admin/menu", async (request, response) => {
    let linkList = await getLinks();
    response.render("menu-list", {title: "Administer menu links", links: linkList});
    });

//CREATE
//add new link
app.get("/admin/menu/add", async (request, response) => {
    let linkList = await getLinks();
    response.render("menu-add", {title: "Add menu link", links: linkList});
});

app.post("/admin/menu/add/submit", async (request, response) => {
    //for a POST form data is passed in the body
    console.log(request.body);
    let newLink = {
        weight:parseInt(request.body.weight),
        name:request.body.name,
        path:request.body.path,
    }
    await addLink(newLink);
    response.redirect("/admin/menu");
});


//UPDATE
app.get("/admin/menu/edit", async (request, response) => {
    if (request.query.linkId) {
        let linkToEdit = await getSingleLink(request.query.linkId);
        console.log("linkId = " + request.query.linkId);
        let links = await getLinks();
        links.forEach(link => {console.log(link.name)});
        response.render("menu-edit", {title: "Edit menu link", links:links, editLink: linkToEdit});
    } else {
        response.render("/admin/menu")
    }
});

app.post("/admin/menu/edit/submit", async (request, response) => {
    let idFilter = {_id: new ObjectId(request.body.linkId)};
    let newLink = {
        weight: parseInt(request.body.weight),
        name: request.body.name,
        path: request.body.path,
    };
    let result = await editLink(idFilter, newLink);

    response.redirect("/admin/menu");
});
 
//Delete
app.get("/admin/menu/delete", async (request, response) => {
    //for a get form data is passsed in the query string
    console.log(request.query.linkId);
    await deleteLink(request.query.linkId);
    response.redirect("/admin/menu");
});

app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}`); //node js is server side console log will log to terminal not the browser console.
})

async function getLinks() {
    let linkList = await db.collection("menuLinks").find({}).sort({weight: 1}).toArray();
    return linkList;
}

async function deleteLink(id) {
    //new ObjectId(<exisiting value>) is used to typecase theid to an ObjectId type. This way of using the ObjectId is deprecated. As of now there doesnt seem to be equivalent method without completely creating a new _id so we're using this .
    let deleteFilter = {_id: new ObjectId(id)};
    let result = await db.collection("menuLinks").deleteOne(deleteFilter);
    return result;
}
/**
 * Insert a menu link document
 */
async function addLink(linkDocument) {
    //insert the document into the collection
    let result = await db.collection("menuLinks").insertOne(linkDocument);
    if (result.insertedId) {
        console.log("Inserted document with id: " + result.insertedId);
    }
    return result;
}


async function getSingleLink(id) {
    const editId = { _id: new ObjectId(id)};
    const result = await db.collection("menuLinks").findOne(editId);
    return result;
}

async function editLink(idFilter, newLink) {
    const options = {upsert: false};
    let result = await db.collection("menuLinks").updateOne(idFilter, {$set: newLink}, options);
    if (result.modifiedCount > 0) {
        console.log("Updated document with id: " + idFilter._id);
    } else {
        console.log("No document found with id: " + idFilter._id);
    }
    return result;
}